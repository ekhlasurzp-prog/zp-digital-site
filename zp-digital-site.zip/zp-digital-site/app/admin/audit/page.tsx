import Link from 'next/link';
import { requireStaff } from '@/lib/auth';
export const metadata = { title: 'অডিট লগ', robots: { index: false } };
export default async function Audit() {
  const { supabase, profile } = await requireStaff();
  if (!['super_admin', 'admin'].includes(profile.role)) return <div className="wrap"><p className="err">এই পাতা দেখার অনুমতি নেই।</p></div>;
  const { data } = await supabase.from('audit_logs').select('id,action,table_name,actor_id,created_at').order('id', { ascending: false }).limit(50);
  return (<div className="wrap"><p><Link href="/admin">← অ্যাডমিন প্যানেল</Link></p><h1>অডিট লগ (সর্বশেষ ৫০)</h1>
    <div className="scroll"><table><thead><tr><th>সময়</th><th>কাজ</th><th>টেবিল</th><th>ব্যবহারকারী</th></tr></thead><tbody>
      {data?.map(l => <tr key={l.id}><td>{new Date(l.created_at).toLocaleString('bn-BD', { timeZone: 'Asia/Dhaka' })}</td><td>{l.action}</td><td>{l.table_name}</td><td>{l.actor_id?.slice(0, 8) ?? 'সিস্টেম'}</td></tr>)}</tbody></table></div></div>);
}
