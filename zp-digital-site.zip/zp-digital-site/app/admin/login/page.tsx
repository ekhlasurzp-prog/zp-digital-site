'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabaseBrowser } from '@/lib/supabase/client';
export default function Login() {
  const r = useRouter(); const [err, setErr] = useState('');
  async function go(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    const { error } = await supabaseBrowser().auth.signInWithPassword({ email: String(f.get('email')), password: String(f.get('password')) });
    if (error) setErr('ইমেইল বা পাসওয়ার্ড ভুল।'); else { r.push('/admin'); r.refresh(); }
  }
  return (<div className="wrap narrow"><h1>অ্যাডমিন লগইন</h1><p className="muted">শুধু অনুমোদিত প্রশাসকরা প্রবেশ করতে পারবেন।</p>
    <form onSubmit={go} className="form"><label>ইমেইল<input name="email" type="email" required autoComplete="email" /></label>
      <label>পাসওয়ার্ড<input name="password" type="password" required autoComplete="current-password" /></label>
      {err && <p className="err" role="alert">{err}</p>}<button className="btn">প্রবেশ করুন</button></form></div>);
}
