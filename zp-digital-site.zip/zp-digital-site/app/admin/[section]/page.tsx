import Link from 'next/link';
import { notFound } from 'next/navigation';
import { SECTIONS, STATUS_BN, type F } from '@/lib/config';
import { requireStaff } from '@/lib/auth';
import { save, setStatus, remove } from '../actions';
export const metadata = { title: 'অ্যাডমিন', robots: { index: false } };
export default async function AdminSection({ params, searchParams }: { params: { section: string }; searchParams: { edit?: string; err?: string } }) {
  const s = SECTIONS[params.section]; if (!s) notFound();
  const { supabase, profile } = await requireStaff();
  const { data: rows } = await supabase.from(s.table).select('*').order('created_at', { ascending: false });
  const ed: any = rows?.find(r => r.id === searchParams.edit);
  const canReview = ['super_admin', 'admin', 'reviewer'].includes(profile.role);
  const canEdit = ['super_admin', 'admin', 'editor'].includes(profile.role);
  const isAdmin = ['super_admin', 'admin'].includes(profile.role);
  const val = (f: F) => { const v = ed?.[f.n]; if (v == null) return ''; return f.t === 'dt' ? new Date(v).toLocaleString('sv', { timeZone: 'Asia/Dhaka' }).slice(0, 16).replace(' ', 'T') : v; };
  const btn = (r: any, to: string, txt: string) => (
    <form action={setStatus} key={to}><input type="hidden" name="slug" value={params.section} /><input type="hidden" name="id" value={r.id} />
      <input type="hidden" name="from" value={r.status} /><input type="hidden" name="to" value={to} /><button className="sm">{txt}</button></form>);
  return (<div className="wrap"><p><Link href="/admin">← অ্যাডমিন প্যানেল</Link></p><h1>{s.label}</h1>
    {searchParams.err && <p className="err" role="alert">ত্রুটি: {searchParams.err}</p>}
    {canEdit && <form action={save} className="form card"><h2>{ed ? 'সম্পাদনা' : 'নতুন যোগ করুন'}</h2>
      <input type="hidden" name="slug" value={params.section} />{ed && <input type="hidden" name="id" value={ed.id} />}
      {s.fields.map(f => f.t === 'bool'
        ? <label key={f.n} className="chk"><input type="checkbox" name={f.n} defaultChecked={!!ed?.[f.n] || (!ed && f.n === 'allow_download')} /> {f.l}</label>
        : <label key={f.n}>{f.l}{f.t === 'area'
          ? <textarea name={f.n} rows={4} defaultValue={val(f)} required={f.req} />
          : <input name={f.n} defaultValue={val(f)} required={f.req} type={f.t === 'num' ? 'number' : f.t === 'date' ? 'date' : f.t === 'dt' ? 'datetime-local' : 'text'} />}</label>)}
      <button className="btn">খসড়া হিসেবে সংরক্ষণ করুন</button>{ed && <Link href={'/admin/' + params.section}>বাতিল</Link>}</form>}
    <h2>তালিকা</h2>{!rows?.length && <p className="muted">এখনো কিছু নেই।</p>}
    {rows?.map(r => (<div key={r.id} className="card row">
      <div><b>{r[s.title]}</b> <span className={'ph st-' + r.status}>{STATUS_BN[r.status]}</span><br /><small className="muted">ID: {r.id}</small></div>
      <div className="acts">
        {(canEdit && (r.status === 'draft' || r.status === 'pending_review' || isAdmin)) && <Link className="sm" href={`/admin/${params.section}?edit=${r.id}`}>সম্পাদনা</Link>}
        {r.status === 'draft' && canEdit && btn(r, 'pending_review', 'পর্যালোচনায় পাঠান')}
        {r.status === 'draft' && canReview && btn(r, 'published', 'প্রকাশ করুন')}
        {r.status === 'pending_review' && canReview && <>{btn(r, 'published', 'অনুমোদন ও প্রকাশ')}{btn(r, 'draft', 'ফেরত দিন')}</>}
        {r.status === 'published' && canReview && <>{btn(r, 'draft', 'প্রকাশ বন্ধ')}{btn(r, 'archived', 'আর্কাইভ')}</>}
        {r.status === 'archived' && canReview && btn(r, 'draft', 'খসড়ায় ফেরান')}
        {isAdmin && <form action={remove}><input type="hidden" name="slug" value={params.section} /><input type="hidden" name="id" value={r.id} /><button className="sm del">মুছুন</button></form>}
      </div></div>))}</div>);
}
