import Link from 'next/link';
import { SECTIONS } from '@/lib/config';
import { requireStaff } from '@/lib/auth';
import { signOut } from './actions';
export const metadata = { title: 'অ্যাডমিন প্যানেল', robots: { index: false } };
export default async function Admin() {
  const { profile } = await requireStaff();
  const isAdmin = ['super_admin', 'admin'].includes(profile.role);
  return (<div className="wrap"><h1>অ্যাডমিন প্যানেল</h1>
    <p>স্বাগতম, {profile.full_name} <span className="ph">{profile.role}</span></p>
    <div className="grid">{Object.entries(SECTIONS).map(([k, s]) => <Link key={k} href={'/admin/' + k} className="card q"><b>{s.label}</b></Link>)}
      {isAdmin && <Link href="/admin/audit" className="card q"><b>অডিট লগ</b></Link>}</div>
    <form action={signOut}><button className="btn out">লগ আউট</button></form></div>);
}
