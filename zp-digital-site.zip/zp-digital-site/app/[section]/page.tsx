import { notFound } from 'next/navigation';
import { SECTIONS, media } from '@/lib/config';
import { supabaseServer } from '@/lib/supabase/server';
export function generateMetadata({ params }: { params: { section: string } }) {
  return { title: SECTIONS[params.section]?.label ?? 'ZP Digital' };
}
export default async function Section({ params }: { params: { section: string } }) {
  const s = SECTIONS[params.section];
  if (!s || s.pub === false) notFound();
  const sb = supabaseServer();
  const { data, error } = await sb.from(s.table).select('*').eq('status', 'published').order(s.order, { ascending: !!s.asc });
  if (error) throw error;
  let members: any[] = [];
  if (params.section === 'committees') {
    members = (await sb.from('committee_members').select('*').eq('status', 'published').order('display_order')).data ?? [];
  }
  const fmt = (d: string) => new Date(d).toLocaleString('bn-BD', { timeZone: 'Asia/Dhaka', dateStyle: 'long', timeStyle: 'short' });
  const items = await Promise.all((data ?? []).map(async (r: any) => {
    let pdf: string | null = null;
    if (params.section === 'books' && r.pdf_path && r.allow_download) {
      pdf = (await sb.storage.from('book-pdfs').createSignedUrl(r.pdf_path, 3600)).data?.signedUrl ?? null;
    }
    return { r, pdf };
  }));
  return (<div className="wrap"><h1>{s.label}</h1>
    {!items.length && <p className="muted">এখানে এখনো কিছু প্রকাশিত হয়নি।</p>}
    <div className="grid">{items.map(({ r, pdf }) => (
      <article key={r.id} className="card">
        {s.img && media(r[s.img]) && <img src={media(r[s.img])!} alt="" className="thumb" />}
        <b>{r[s.title]}</b>
        {s.sub && r[s.sub] && <div className="muted">{r[s.sub]}</div>}
        {params.section === 'events' && r.starts_at && <div className="muted">{fmt(r.starts_at)}</div>}
        {s.body && r[s.body] && <p>{r[s.body]}</p>}
        {pdf && <a className="btn" href={pdf} target="_blank" rel="noopener">পিডিএফ খুলুন</a>}
        {r.youtube_url && <a className="btn" href={r.youtube_url} target="_blank" rel="noopener">YouTube-এ দেখুন (অনলাইন)</a>}
        {params.section === 'committees' && members.filter(m => m.committee_id === r.id).map(m => <div key={m.id}>• {m.member_name_bn}{m.role_bn ? ` — ${m.role_bn}` : ''}</div>)}
      </article>))}</div></div>);
}
